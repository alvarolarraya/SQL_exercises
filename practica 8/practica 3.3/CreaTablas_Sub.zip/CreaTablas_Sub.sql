-- select 'drop table ' || table_name || ' cascade constraints;' from user_tables;

prompt **** Creando PROVINCIAS ****

create table  provincias
( codpro    varchar2(2),
  nombre    varchar2(30),
constraint pk_provincias primary key (codpro));

prompt -----> Poblando PROVINCIAS...
@provincias;

prompt **** Creando PUEBLOS ****

create table  pueblos
( codpue    varchar2(5),
  nombre    varchar2(40),
  codpro    varchar2(2),
constraint pk_pueblos primary key (codpue),
constraint fk_pue_pro foreign key (codpro) references provincias on delete set null);

prompt -----> Poblando PUEBLOS...
@pueblos;

prompt **** Creando CLIENTES ****

create table  clientes
( codcli    number(5),
  nombre    varchar2(50) not null,
  direccion varchar2(50) not null,
  codpostal varchar2(5),
  codpue    varchar2(5),
constraint pk_clientes primary key (codcli),
constraint fk_cli_pue foreign key (codpue) references pueblos on delete set null);

prompt -----> Poblando CLIENTES...
@clientes;

prompt **** Creando ARTICULOS ****

create table  articulos
( codart    varchar2(8),
  descrip   varchar2(40),
  precio    number(6,1) not null,
  stock     number(6),
  stock_min number(6) default '2',
constraint pk_articulos primary key (codart));

prompt -----> Poblando ARTICULOS...
@articulos;

prompt **** Creando CABECERAS DE FACTURA ****

create table  facturas
( codfac    number(6),
  fecha     date,
  codcli    number(5),
  iva       number(2),
  dto       number(2),
  total	    number(8,2),
constraint pk_facturas primary key (codfac),
constraint fk_fac_cli foreign key (codcli) references clientes on delete cascade,
constraint ch_dto check (dto between 0 and 100),
constraint ch_iva check (iva in(0,4,7,16)));

prompt -----> Poblando CABECERAS DE FACTURA...
@facturas;

prompt **** Creando LINEAS DE FACTURA ****

create table  lineas_fac
( codfac    number(6),
  linea     number(2),
  cant      number(5) not null,
  codart    varchar2(8),
  precio    number(6,1) not null,
  dto       number(2),
constraint pk_lineas_fac primary key (codfac,linea),
constraint fk_lin_fac foreign key (codfac) references facturas on delete cascade,
constraint fk_lin_art foreign key (codart) references articulos
 on delete set null);

prompt -----> Poblando LINEAS DE FACTURA...
@lineas_fac;