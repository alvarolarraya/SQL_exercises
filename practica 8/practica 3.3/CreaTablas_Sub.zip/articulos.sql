insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10024','PIEZA MICRO TEGUI EUROPA',310,NULL,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10025','TELEFONO TIGUI EUROPA',165,18,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10026','ALIMENTADOR TEGUI EUROPA',74,13,NULL);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10027','CONTADOR 2X30/60 MAS ICP 25A',453,7,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10023','PORTALAMPARAS CURVO',103,NULL,14);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10030','MARCO BGC IBIZA 1 ELEMENTO',271,8,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ME200','MARCO BJC IBIZA 2 ELEMENTOS',2250,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TE1401','INTERRUPTOR BJC IBIZA BLANCO',690,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TE1001','COMUTADOR BJC IBIZA BLACO',1260,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TE1111','CRUZAMIENTO BJC IBIZA BLANCO',2350,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TE5501','DOBLE INTERRUPTOR BJC IBIZA',4200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TE7200','DOBLE COMUTADOR BJC IBIZA BLANCO',2200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TE5514','BASE NORMAL BJC IBIZA BLANCO',9000,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CICP','BASE ESSCO BJC IBIZA BLANCO',13398,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAMCVO','BASE TT DESPLAZADA BJC IBIZA BLAN',150,18,18);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1008','PERFIL TICINO TEKNE GRIS 1 E',203,15,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1009','MARCO TICINO TEKME 2 E GRIS',271,15,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1010','PERFIL TICINO TEKNE 2 E GRIS',250,10,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1011','MARCO TICINO TEKNE 3 E GRIS',149,31,30);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1012','PERFIL TICINO TEKNE 3 E GRIS',210,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('FELM3','PLACA CIEGA TICINO TEKNE',24500,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CAJA2','BASE TFNO TICINO TEKNE',5680,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TP200','PERFIL TICINO TEKNE GRIS 2 E',856,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TP2T','CORTACIRCUITO TICINO TEKNE GRIS',26820,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10020','CAJA MEDES DIFERENCIALES 1/12E',119,33,15);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10021','CAJA TEGUI EUROPA 1 MODOLO',92,7,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T10022','MARCO TEGUI EUROPA 1 ELEMENTO',247,NULL,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1023','MODOLO TEGUI EUROPA',103,13,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5172B','CORTACIRCUITOS 15A PLASTIMETAL',222,5,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5173B','CAJAS 1,2,3 ELEMENTOS  PLASTIMETA',302,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5117B','PORTERO FELMAX 3 LINEAS',494,8,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP605','CAJA DE PROTECCION 125A',321,10,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP615','CAJA TRES ELEMENTOS',369,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP635','PLACA 1,2,3 E TICINO SERIE TEKNE',664,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP504','SOPORTE PLACA TICINO TEKNE',166,13,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP504T','COMUTADOR TICINO TEKNE',231,9,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP515','INTERRUPTOR TICINO SERIE TEKNE',295,13,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP714','CRUZAMIENTO TICINO S,TEKNE',257,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP724','PUSADOR LUZ TICINO S, TEKNE',391,11,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZP903','PULSADOR CAMPANA TICINO S, TEKNE',85,50,23);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZNP3L','CORTACIRCUITO TICINO S,TEKNE',17850,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZNCL','BASE T,T LATERAL TICINO S, TEKNE',6940,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1001','BASE NORMAL TICINO S,TEKNE',35,93,65);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1002','BASE T,T DESPLAZADA TICINO TEKNE',135,30,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1003','PORTERO ELECTRONICO FELMAX 2 LIN',117,38,36);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1004','CAJA ACOMETIDA III 80 A',249,10,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1005','PIQUETA TOMA TIERRA 2MTS',201,22,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1006','KIT PORTERO ELECTRONICO 2 TELEFO',563,7,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T1007','MARCO 1 ELEMENTO GRIS',469,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('REF1X20','REGLETA FLUORESCENTE 1X36 BAJO F',1450,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('REF2X40','REGLETA FLUORESCENTE 1X18 BAJO F',2100,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('REF2X20','MEMORIA Y TRAMITACION BOLETIN',2000,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TE3102','INTERRUPTOR BJC LINEAL BLANCO',3250,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('SI4P25A','BASE BJC LINEAL BLANCO',5950,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CENTRA1','CORTACIRCUITO BJC LINIAL',52427,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('U3002','INTERRUPTOR BJC LINIAL BLANCO',916,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LPEO60','CRUZAMIENTO BJC LINIAL BLANCO',800,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LPER100','CORTACIRCUITO BJC LINIAL PEQUE%O',1400,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2710','INTERRUPTOR NIESEN LISA BLANCO',1443,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RF1X36B','COMUTADOR NIESEN LISA BLANCO',1550,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RF1X18B','CRUZAMIENTO NIESEN LISA BLACO',1450,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TRAMI1','BASE DE ENCHUFE NIESEN LISA BLAN',5000,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('B932B','BASE DE ENCHUFE NIESEN LISA BLAN',429,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('B914B','BASE DE ENCHUFE NIESEN LISA BLAN',275,9,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('B944B','PULSADOR NIESEN LISA CAMPANA B',431,8,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('B930B','CORTACIRCUITO NIESEN LISA BLANCO',391,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('B933B','PLACA 1 ELEMENTO NIESEN LISA B',482,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('B924B','PLACA 2 ELEMENTOS NIESEN LISA B',380,13,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5101B','PLACA 3 ELEMENTOS NIESEN LISA B',410,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5102B','TOMAS DE TELEFONO NIESEN LISA B',464,8,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5110B','INTERRUPTOR PLASTIOMETAL MARFIL',889,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5103B','COMUTADOR PLASTIMETAL',291,6,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5106B','CRUZAMIENTO PLASTIMETAL',382,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5188B','BASE DE ENCHUFE PLASTIMETAL',305,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5104B','BASE ENCHUFE TT PLASTIMETAL',406,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5108B','BASE PLASTIMETAL TT LATERAL',412,12,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ZN5171B','CORTACIRCUITOS 10A PLASTIMETAL',150,30,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LACU300','CENTRALIZACION 3 MONO 1 COMERCIAL',1000,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAC20','DOBLE INTERRUPTOR UNESA METROPOLI',125,19,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAC40','PLAFON ESTANCO OBALADO 60 W',125,NULL,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LACO18F','PLAFON ESTANCO CILINDRICO 100 W',780,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('REF1X40','VENTANA VA 27 10M',1550,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LACU1500','TERMICO SIEMENS 4 X 25 A',3200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAE100','LAMPARA ESF R27 60W CLARA',85,21,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAE60','LAMPARA ESF R27 40W CLARA',85,14,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAE40','LAMPARA ESF R27 25W CLARA',85,9,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAE25','LAMPERA ESF R27 40W MATE',85,57,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA1460EC','REACTANCIA TUBO FLUORESCENTE 20W',95,24,25);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA1440EC','REACTANCIA FLUERESCENTE 32W',95,17,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA1425EC','REACTANCIA FLUORESCENTE 40W',95,52,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA1460EM','REACTANCIA FLUORESCENTE 65W',95,35,32);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA1440EM','REACTANCIA VAPOR MERCURIO 80W',950,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA1425EM','REACTANCIA VAPOR MERCURIO 125W',95,42,15);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA2760EC','REACTANCIA VAPOR MERCURIO 250W',95,32,20);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA2740EC','REACTANCIA VAPOR MERCURIO 400W',95,12,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA2725EC','TRANSFORMADOR 12V 50W',95,51,20);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA2760EM','LAMPARA VAPOR MERCURIO 125W',95,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RF20','LAMPARA VAPOR MERCURIO 250W',560,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RF32','LAMPARA VAPOPR MERCURIO 400W',560,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RF40','LAMPARA MESCLA 160W',560,7,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RF65','LAMPARA LUZ MESCLA 250',1000,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RV80','LAMPARA DULUX 18 W',990,4,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RV125','LAMPARA DULUX 36 W',990,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RV250','LAMPARA BAJO CONSUMO 13W',2550,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RV400','LAMPARA BAJO CONSUMO 9W',3600,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('RT1250','BOMBILLA DESLUMBRANTE 100W',1000,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAV125','BOMBILLA DESLUMBRANTE 60W',990,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAV250','LAMPARA CUARZO YODO 1500W',2550,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAV400','LAMPARA CUARZO YODO 300W',3600,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAM160','CEBADOR 20 W',1400,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAM250','CEBADOR 40 W',2450,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LADU16','CONDENSADOR 18 M FARADIOS',1990,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LADU36','REGLETA FLUORESCENTE 1X40 W',2272,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAVC18','REGLETA FLUORESCENTE 1X20 W',3050,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAVC9','REGLETA FLUORESCENTE 2X40 W',3050,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAD100','REGLETA FLUORESCENTE 2X20',130,34,33);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAD60','VICERA PLACA 2 ELEMENTOS',130,25,17);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF15','LAMPARA STANDRD 60W CLARA',470,7,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF18L','LAMPARA STANDRD 40W CLARA',895,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF20N','LAMPARA STANDRD 25W CLARA',2400,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('FAF36L','LAMPARA ESF R14 60W CLARA',895,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF40CO','LAMPARA ESF R14 40 CLARA',1100,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF65','LAMPARA ESF R14 25W CLARA',550,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF65L','LAMPARA ESF R14 60W MATE',1220,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF8','LAMPARA ESF R14 40W MATE',800,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAA50','LAMPARA ESF R14 25W MATE',1000,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI775S','CAJA DIFERENCIALES 1-12 E. PUERTA',1881,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI800E','CAJA DIFERENCIALES 1-8 Elem. VILA',1102,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI801E','CAJA DIFERENCIALES 2-8 Elem. VILA',1858,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI824S','CAJA DIFERENCIALES 3-8 Elem. VILA',8200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI830E','CAJA DIFERENCIALES 4-8 Elem. VILA',1400,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI831E','INTERRUPTOR HORARIO PGRAMA SEMANA',1400,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI832E','BASE SALIDA INCLINADA LEGRAND III',1400,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI833E','PIQUETA TT ENCHUFABLE 200M',1400,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI845S','PIEZA DE EMPALME PIQUETA TT',1132,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI846S','GRAPA EMPALME PIQUETA TT',1240,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI847S','TUBO FLUORESCENTE 40 W',1530,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI860E','TUBO FLORESCENTE 20 W',1190,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI861E','TUBO FLUORESCENTE 22W CILINDRICO',1190,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI862E','TUBO FLUORESCENTE 32W CILINDRICO',1190,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI863E','TUBO FLUORESCENTE 40W CILINDRICO',1190,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('l03755','TUBO FLUORESCENTE 15 W',8424,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('l58068','TUBO FLUORESCENTE 18W TLD',1060,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CPT200','TUBO FLUORESCENTE 20W LUZ NEGRA',2100,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CPT001','TUBO FLUORESCENTE 36W TLD',350,13,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CPT002','TUBO FLUORESCENTE 40W COLOR',310,9,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF40','TUBO FLUORESCENTE 65W',270,15,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF20','TUBO FLUORESCENTE 65W TLD',270,13,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF22C','TUBO FLUORESCENTE 8W',900,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF32C','LAMPARA ALOGENA 50 W',900,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAF40C','LAMPARA STANDRD 100W CLARA',1200,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI24E','CAJA EMPALME VILAPLANA 200 x 200',76,12,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI25E','CAJA EMPALME VILAPLANA 200 x 130',120,24,NULL);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI500','CAJA DIFERENCIALES 1 E. VILAPLANA',4200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI523E','CAJA DIFERENCIALES 2 E. VILAPLANA',55,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI531E','CAJA DIFERENCIALES 4 E. VILAPLANA',52,14,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI532E','CAJA DIFERENCIALES 6 E. VILAPLANA',83,14,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI533E','CAJA DIFERENCIALES 8 E. VILAPLANA',98,8,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI535E','CAJA DIFERENCIALES 12 E. VILAPLAN',180,6,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI536E','CAJA DIFERENCIALES 1-12 E. VILAPL',224,11,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI546E','CAJA DIFERENCIALES 18 E. VILAPLAN',600,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI553E','CAJA DIFERENCIALES 1-6 E. VILAPLA',400,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI557E','CAJA DIFERENCIALES 1-8 E. VILAPLA',265,15,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI718S','CAJA DIFERENCIALES 1-12 E. VILAPL',190,20,21);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI719S','CAJA DIFERENCIALES 2-12 E. VILAPL',214,19,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI720S','CAJA DIFERENCIALES 3-12 E. VILAPL',248,20,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI725S','CAJA DIFERENCIALES 12 E. CON PUER',384,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI726S','CAJA DIFERENCIALES 2-12 E. PUERTA',490,7,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI727S','CAJA DIFERENCIALES 16 E SUPERFICI',730,6,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI731E','CAJA DIFERENCIALES 1-12 Elem. VIL',790,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI735E','CAJA DIFERENCIALES 2-12 Elem. VIL',790,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI741E','CAJA DIFERENCIALES 3-12 Elem. VIL',650,6,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI745E','CAJA DIFERENCIALES 4-12 Elem. VIL',680,7,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI773S','CAJA DIFERENCIALES 1-6 E. PUERTA',807,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI774S','CAJA DIFERENCIALES 1-8 E. PUERTA',1330,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UNEX4090','CAJA VILAPLANA SPERFICIE 60',1012,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UP1603','CAJA EMPALME VILAPLANA 80',14200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UP250P3','CAJA EMPALME VILAPLANA 100',19570,16657,10662);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UP400P3','CAJA EMPALME VILAPLANA 100 x 100',20870,30469,28557);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UP80A2','CAJA EMPALME VILAPLANA 160 x 100',3995,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UP80A3','CAJA EMAPLME VILAPLANA 150 x 150',5040,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('VI1017B','CAJA EMPALME VILAPLANA 250 x 250',7303,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UI400P4','CAJA SUPERFICIE VILAPLANA 100',18340,10529,3075);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UIR100A','CAJA DIFERENCIALES 36 ELEMENTOS',13900,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFX4','TUBO RIGIDO PROTECCION 5',7100,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFX5','TUBO SAPA FORRADO   11',1820,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFXK1','TUBO SAPA FORRADO	13.5',13900,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFXK2','TUBO SAPA FORRADO	16',19250,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLGX2','TUBO SAPA FORRADO   21',11350,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TNF11','TUBO SAPA FORRADO   29',41,21,21);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TNF13.5','TUBO SAPA FORRADO	 36',43,109,95);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TNF16','TUBO SAPA FORRADO   9',59,74,60);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TNF21','TUBO SAPA   11',85,13,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TNF29','TUBO SAPA   13.5',120,35,31);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TRI29','TUBO SAPA   16',112,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSF11','TUBO SAPA   21',315,10,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSF13.5','TUBO SAPA	 29',381,11,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSF16','TUBO SAPA   9',420,NULL,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSF21','CAJA 2 CONTADORES Y C/C EMPOTRAR',619,4,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSF29','CAJA 1 CONTADOR TRIFASICO Y C/C',826,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSF36','CAJA 1 COTADOR MONOFASICO Y C/C E',1126,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSF9','CAJA 1 CONTADOR TRIFASICO Y C/C E',258,8,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSP11','CAJA 3 CONTADORES CENTRALIZACION',229,5,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSP13.5','CAJA 4 CONTADORES CENTRALIZACION',272,16,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSP16','CAJA DOS CONTADORES MONOFASICOS',313,10,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSP21','INTERRUPTOR DE ROTURA BRUSCA 100',452,6,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSP29','INTERRUPTOR DE ROTURA BRUSCA 250',587,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TSP9','INTERRUPTOR DE ROTURA BRUSCA 400',204,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UCM 7','INTERRUPTOR ROTURA BRUSCA 100 A',26119,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UCM2','CANALETA UNEX 40X90',5620,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UCM3','CAJA DE PROTECCION 160 A III.N',8240,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UCM4','CAJA DE PROTECCION 250 A III.N',7600,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UCM5','CAJA DE PROTECCION 400 A III.N',11826,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UCM6','CAJA DE PROTECCION 80 A F.N',16870,4339,3403);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UCM8','CAJA DE PROTECCIOM 80 A III.N',7860,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UIR160','PANTALLA VILAPLANA 2X40W',13900,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('UIR250','CAJA SUPERFICIE VILAPLANA 80',16720,25399,5346);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THM21','EQUIPO PORTERO ELECTRONICO 2 LINE',110,30,24);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THM29','PLACA GOLMAR 8 PULSADORES',164,13,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THM36','TUBO DURO FLEXIBLE NEGRO  11',231,19,14);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFX1','TUBO DURO FLEXIBLE NEGRO  13.5',2240,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFX1N','TUBO DURO FLEXIBLE NEGRO  16',1100,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFX2','TUBO DURO FLEXIBLE NEGRO  21',10100,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TLFX3','TUBO DURO FLEXIBLE NEGRO  29',400,7,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC71011','CURVA FERCONDUR   36',632,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC80','MANGUITO TUBO FERCONDUR   11',172,7,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TF11','MANGUITO TUBO FERCONDUR   13.5',109,36,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TF13.5','MANGUITO TUBO FERCONDUR   16',122,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TF16','MANGUITO TUBO FERCONDUR   21',152,26,NULL);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TF21','MANGUITO TUBO FERCONDUR   29',206,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TF29','MANGUITO TUBO FERCONDUR   36',317,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TF36','TUBO HIERRO	11',413,NULL,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFC21','TUBO HIERRO	 13.5',256,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFC29','TUBO HIERRO	 16',349,10,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFC36','TUBO HIERRO	 21',468,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFM11','TUBO HIERRO	 29',48,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFM13.5','TUBO HIERRO   36',50,85,38);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFM16','CURVA TUBO HIERRO   11',55,23,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFM21','CURVA TUBO HIERRO   13.5',58,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFM29','CURVA TUBO HIERRO   16',68,68,29);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TFM36','CURVA TUBO HIERRO   21',85,49,44);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TH11','CURVA TUBO HIERRO   29',237,20,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TH13.5','CURVA TUBO HIERRO	36',257,NULL,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TH16','MANGUITO HIERRO 11',284,12,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TH21','MANGUITO HIERRO 16',356,9,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TH29','MANGUITO HIERRO 21',499,10,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TH36','MANGUITO HIERRO 29',783,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THC11','MANGUITO HIERRO 36',141,32,25);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THC13.5','TELEFONO MURAL FELMAX 2044',167,28,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THC16','TELEFONO PARET CORDON RIZADO',176,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THC21','PLACA MURAL FELMAX',259,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THC29','PULSADOR PARA PLACA FELMAX',426,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THC36','ALIMENTADOR FELMAX 2156',757,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THM11','ABREPUERTAS FELMAX',65,21,18);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('THM16','EQUIPO PORTERA FELMAX 1 LINEA3',86,35,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4750','CURVA CANAL E. BLANCO',1076,4,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T503','CURVA CANAL I. BLANCO',90,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC100','TUBO EMPOTRAR   23',65,66,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC11','TUBO EMPOTRAR   29',18,193,164);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC125','TUBO EMPOTRAR   36',210,19,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC13.5','CANALETA UNEX 40X110',24,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC13.5N','TUBO EMPOTRAR   50',7,422,54);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC16','TUBO EMPOTRAR   65',26,175,158);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC1625','CANAL BLANCO 70 mm',320,8,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC1640','TUBO EMPOTRAR   80',405,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC16401','TUBO FERCONDUR   11',160,25,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC16402','TUBO FERCONDUR   13.5',128,38,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC23','TUBO FERCONDUR   16',44,15,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC29','TUBO FERCONDUR   21',65,59,14);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC36','TUBO FERCONDUR   29',99,5,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC40110','TUBO FERCONDUR   36',1214,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC50','CURVA FERCONDUR   21',84,27,26);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('TC60','CURVA FERCONDUR   29',124,19,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3166136','BASE TOMA LATERAL TICINO SERIE LI',1019,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3181231','TAPA CIEGA TICINO SERIE LIVING',4056,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('SATF1','INTERRUPTOR TICINO SERIE LIVING',6270,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('SATF2','COMUTADOR TICINO SERIE LIVING',6490,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('SATF3','CRUZAMIENTO TICINO SERIE LIVING',8200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('SATF4','BASE N TICINO SERIE LIVING',7980,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('SATF5','CORTACIRCUITO TICINO SERIE LIVING',12200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('SATF6','BASTIDOR TICINO SERIE LIVING',14670,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T13940/1','PLACA TICINO SERIE LIVING',465,10,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T23932','BASTIDOR TICINO SERIE LIVING',465,9,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4440','PLACA TICINO SERIE LIVING',579,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4500','CAJA EMPOTRAR 3 ELEMENTOS TICINO',56,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4501','TUBO EMPOTRAR   100',496,8,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4503','TUBO EMPOTRAR   11',570,7,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4512','TUBO CANALIZACION 125 m/m',998,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4522','TUBO EMPOTRAR   13.5',448,6,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4588','TUBO EMPOTRAR 13.5',748,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4703','TUBO EMPOTRAR   16',159,30,14);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4713','CANAL SUPERFICIE BLANCO',1076,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('T4740','CANAL SUPERFICIE BLANCO',187,11,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3120431','BASE T.T. - CORTACIRCUITOS BLANCO',1000,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3120436','BASE T.T - C/C MARRON DEC. SIMON',1488,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3125131','BASE ENCHUFE NORMAL CON T.T. BLAN',1495,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3125136','BASE ENCHUFE T.T. DES. MARRON DEC',1495,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3125431','TOMAS DE SENAL RADIO TV SIMON 31',1537,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3125436','TOMAS DE SENAL RADIO TV SIMON 31',1728,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3143131','PLACA 1 Elem. BLANCA SIMON SERIE',386,6,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3143136','PLACA 1 Elem. NEGRA SIMON SERIE 3',581,6,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3143231','PLACA 2 Elem. BLANCA SIMON SERIE',445,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3143236','PLACA 2 Elem. NEGRA SIMON SERIE 3',657,4,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3143431','PLACA 3 Elem. BLANCA SIMON SERIE',850,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3143436','PLACA 3 Elem. NEGRA SIMON SERIE 3',1114,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3144231','PULSADOR CAMPANA BLANCO SIMON SER',407,11,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3144236','PULSADOR CAMPANA MARRON DEC. SIMO',603,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3149136','PULSADOR LUZ BLANCO SIMON SERIE 3',1031,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3149236','PULSADOR LUZ MARRON DEC. SIMON SE',1031,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3161031','PULSADOR CAMPANA BLANCO CON VISOR',126,20,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3161032','PULSADOR CAMPANA MARRON D. CON VI',126,33,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3162031','PULSADOR LUZ BLANCO CON VISOR SIM',196,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3162032','PULSADOR LUZ MARRON DEC. CON VISO',196,5,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3163031','REGULADOR LUZ BLANCO SIMON SERIE',332,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3163032','BLOQUE EMERGENCIA SATF 32 L',332,11,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3165031','BLOQUE EMERGENCIA SATF 32 L PER',564,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3165036','BLOQUE EMERGENCIA SATF 60 L',800,6,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3165131','BLOQUE EMERGENCIA SATF 60 L PER',564,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3165136','BLOQUE EMERGENCIA SATF 150 L',800,6,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3166031','BLOQUE EMERGENCIA 300 L',933,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3166036','BASES TICINO TT LATERAL 16 A',1019,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3166131','TAPAS TICINO 1 E TRAS CUADRO',933,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3120131','BASE ENCHUFE SCHUCCO BLANCO SIMON',632,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3120136','BASE NORMAL T.T. MARRON DEC. SIMO',875,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3110436','BASE ENCHUFE NORMAL MARRON DE. SI',1371,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P1044','CRUZAMIENTO PLASTIMETAL',247,NULL,NULL);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P434L','REGULADOR LUZ PLASTIMETAL UNICAJA',541,9,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P500TV','CORTACIRCUITOS 10 A. PLASTIMETAL',219,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P504','CORTACIRCUITOS 16 A. PLASTIMETAL',143,34,17);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P504T','CAJA EMPOTRAR HASTA 3 Elem. PLAST',198,8,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P515','CAJA EMPOTRAR hasta 6 Elem. PLAST',253,13,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P605','CAJA 1 Elem. PLASTIMETAL',275,16,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P605L','CAJA 2 Elem. PLASTIMETAL',456,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P615','CAJA 3 Elem. PLASTIMETAL',317,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P615L','CAJA SUPERFICIE hasta 3 elem. PLA',499,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P635','CAJA SUPERFICIE hasta 6 elem. PLA',569,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P695','INTERRUPTOR ROTURA BRUSCA 100 A M',2200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P714','GRAPA SUJETACABLES PARA PIQUETA',220,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P724','PIQUETA TOMA TIERRA ENCHUFABLE',335,12,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P903','CORTACIRCUITOS SIMON SERIE 24',73,61,22);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P904','PORTAFUSIBLES BLANCO SIMON SERIE',110,18,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P910','PORTAFUSIBLES DORADO DEC. SIMON S',43,51,17);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P912','INTERRUPTOR UNIPOLAR BLANCO SIMON',60,29,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P913','INTERRUPTOR MARRON D. SIMON SERIE',90,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P923','INTERRUPTOR 1P. CON VISOR BLANCO',282,7,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P924','INTERRUPTOR MARRON DEC. CON VISOR',397,8,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('PCMIB','CONMUTADOR BLANCO SIMON SERIE 31',13900,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('PMGF','CONMUTADOR MARRON DEC. SIMON SERI',310,10,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('PMTT200E','CONMUTADOR CON VISOR BLANCO SIMON',1740,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S24000','CONMUTADOR MARRON DEC. CON VISOR',237,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3100131','CONMUTADOR CRUCE BLANCO SIMON SER',624,5,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3100136','CONMUTADOR CRUCE MARRON DEC. SIMO',848,5,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3110131','CONMUTADOR CRUCE CON VISOR BLANCO',561,7,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3110136','CONMUTADOR CRUCE MARRON D. CON VI',796,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('S3110431','BASE ENCHUFE NORMAL BLANCA SIMON',931,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8019BA','RELOG ORBIS SIN RESERVA DE CUERDA',1348,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8050BA','AUTOMATICO DE ESCALERA ORBIS T11',900,4,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8060','AUTOMATICO DE ESCALERA ORBIS T15',18,136,57);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8071BA','AUTOMATICO ESCALERAS ORBIS T16',147,21,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8072BA','AUTOMATICO ESCALERAS MERCURIO T9',229,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8073BA','PLACA 1 elem. PLASTIMETAL',388,8,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8088BA','PLACA 4 Elem. PLASTIMETAL',499,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8100','PULSADOR LUZ PLASTIMETAL',18,72,45);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ORBILUX','TOMA TV PLASTIMETAL UNICAJA',6660,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ORC72H','BASE ENCHUFE NORMAL PLASTIMETAL',8480,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ORS00H','BASE ENCHUFE CON T.T. PLASTIMETAL',5110,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ORT11','BASE ENCHUFE SCHUCO PLASTIMETAL',2440,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ORT15','INTERRUPTOR PLASTIMETAL',3800,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ORT16','INTERRUPTOR PLASTIMETAL UNICAJA',3590,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ORT9','CONMUTADOR PLASTIMETAL',4310,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('P1031','COMUTADOR PLASTIMETAL LUZ  UNICAJ',154,8,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5072','PULSADOR LUZ PILOTO NIESSEN TRAZO',222,11,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5073','PULSADOR TIMBRE NIESSEN TRAZO BLA',305,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5088','CORTACIRCUITOS NIESSEN TRAZO BLAN',253,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N6190','CRUZAMIENTO NIESSEN TRAZO BLANCO',424,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N6192','CRUZE NIESSEN TRAZO BLANCO ALPINO',220,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8001.2','TOMA DE TELEFONO NIESSEN TRAZO BL',1008,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8001BA','ZUMBADOR NIESSEN TRAZO BLANCO ALP',655,6,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8002BA','TOMAS TV NIESSEN BLANCO ALPINO',738,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8003BA','CARTUCHOS FUSIBLES 6 A CRISTAL',434,8,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8004.5','MARCOS 1 ELEMENTOS NIESSEN TRAZO',1360,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8004.6B','MARCO 2 ELEMENTOS NIESSEN BLACO A',1259,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8004BA','MARCO 3 ELEMENTOS NIESSEN TRAZO B',658,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8008BA','BASE TT LATERAL NIESSEN TRAZO BLA',728,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8010','CARTUCHOS FUSIBLES 10 A CRISTAL',1261,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8010BA','FOTOCEDULA ORBIS',1362,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N8017BA','RELOG ORBIS CON RESERVA DE CUERDA',566,7,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5071','PULSADOR LUZ PILOTO NIESSEN TRAZO',150,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR400','BLOQUE EMERGENCIA SAFT 300 LUMENE',4700,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR40125','BLOQUE EMERGENCIA SAFT 60 LUMENES',1830,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR50','TIMBRE EE E2646',315,15,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR63','TIMBRE DING DONG E2690',270,8,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR63C','TIMBRE DING DONG E2646',480,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR65','TULIPAS CUELLO ALTO',1000,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR80','PANTALLA 2 x 36 W. BLANCANIEVES',270,14,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LARD100','HOJO DE BUEY LLEDO EMPOTRAR B',130,36,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LARD60','HOJO DE BUEY LLEDO EMPOTRAR B',120,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LASA30','LUMINARIA 1X36 SUPERFICIE COCINA',6270,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LASA300','PANTALLA DE RIEL STAFF 71090',14670,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LASA60','TRANSFORMADOR 12 V 50 W',7980,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LATIM','INTERRUPTOR NIESEN SERIE LISA',1350,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LATIM1','CONMUTADOR NIESEN SERIE LISA',1380,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LATIM2','BASE ENCHUFE NORMAL NIESEN SERIE',1200,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LATL','PULSADOR TIMBRE NIESEN SERIE LISA',350,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LL2X36B','PULSADOR LUZ NIESEN SERIE LISA',8297,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LLG11','BASE ENCHUFE CON T.T. DES. NIESEN',1406,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LLG12','CORTACICUITOS NIESEN SERIE LISA',1654,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LLS1X36','CRUZAMIENTO NIESEN SERIE LISA',7566,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LLST90','DOBLE CONMUTADOR NIESEN SERIE LIS',17291,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LLTRNS50','PLACA 1 Elem. NIESEN SERIE LISA',1048,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5001','PLACA 2 Elem. NISEN SERIE LISA',410,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5002','PLACA 3 Elem. NIESEN SERIE LISA',464,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5003','BASE ENCHUFE SCHUCO NIESEN SERIE',291,5,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5004','LAMPARA NEON NIESSEN LUZ PUNTUAL',406,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5004L','LAMPARITA NEON NIESEN SERIE LISA',328,NULL,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5006','INTER BIPO NIESSEN TRAZO BLANCO A',382,8,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5008','INTER UNI NIESSEN TRAZO BLANCO AL',412,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5010','COMUT NIESSEN TRAZO BLANCO ALPINO',884,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('N5022','BASE NORMAL NIESSEN BLANCO ALPINO',869,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR40','BLOQUE EMERGENCIA SAFT 30 LUMENES',489,5,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L90336','CAJA EMPALME 153 x 110 LEGRAND',782,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L91800','CAJA EMPALME 310 x 240 LEGRAND',580,6,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L91812','REGLETA FLUORESCENTE 1CX40',683,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L91814','TUBO FLUORESCENTE 40W',816,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L91827','PORTALAMPARAS DOBLE ENCHUFE R27',988,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L92010','PORTALAMPARAS ECONOMICO R27',115,7,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L92117','PORTALAMPARAS CURBO 14',730,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L92119','PORTALANPARAS 14 CURBO',995,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L92212','SOFITO 60 W',172,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L92222','TE DE EMPALME CARRIL ILUMINADO',270,15,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L92252','APLIQUE ESTANCO OBALADO',645,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L92282','PORTOLAMPARAS PARA BOMBILLA ALOGE',6748,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA1X40','PANTALLA FLUORESCENTE 1X40 DIFUSO',1550,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LA40','PORACEBADOR',300,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAMP27D','PORTALAMPARAS PORCELANA 27',250,18,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAMP27E','PANTALLA CONDIFUSOR A RALLAS 1X32',60,26,23);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAMPC14','PATALLA CON PROTECTOR 1X40W',60,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAMPT14','PROTECTOR TUBO FLUORESCENTE 18 W',60,69,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAMSOFI','PORTATUBO FLUORESCENTE',600,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAMTE','RREGGLETA FLUORESCENTE 1X20 W',1103,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAOBYO','REGLETA FLUORESCENTE DE 1 X 40 W',900,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPALO','REACTANCIA 20 W 220 V',210,16,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPAMN','REACTANCIA PARA LAMPARA VAPOR MER',6080,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPC','REACTANCIA 40 W 220V',65,NULL,42);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPC27','REACTANCIA LAMPARA VAPOR DE MERCU',148,19,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPC32L','REACTANCIA 125V 40W PARA FLUORESC',6200,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPF1X40','BOMBILLA REFLECTORA 50 mm.',6150,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPRO','BOMBILLA REFLECTORA 63 mm',402,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAPT','LAMPARA REFLECTORA 63 COLOR',120,17,16);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR1X20','REACTANCIA 65 W 220 V',1450,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR1X40','BOMBILLA REFLECTORA 80 mm.',1550,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR20','LAMPARA DESLUMBRANTE 100W',489,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('LAR250','LAMPARA DESLUMBRANTE 60W',3680,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86225','CAJA 3 E. LEGRAND SERIE MOSAIC',363,11,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86231','CAJA 2 E. SUPERFICIE LEGRAND SERI',934,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86330','CAJA 4 E. SUPERFICIE LEGRAND SERI',153,8,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86331','CAJA 6 E. SUPERFICIE LEGRAND SERI',153,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86350','CAJA LEGRAND 6 - 6 Elem. LEGRAND',80,28,19);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86351','LAMPARA PULSADOR LEGRANG SUPERFIC',80,29,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86390','TOMA FLEXO LEGRAND TRAS CUADRO',1109,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89125','INTERRUPTOR LEGRANG SUPERFICIE ES',150,29,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89126','PULSADOR LEGRANG SUPERFICIE ESTAN',180,10,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89127','PULSADOR LEGRAND SUPERFICIE ESTAN',281,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89159','PULSADOR LEGRAD DE SUPERFICIE',70,38,29);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89320','CAJA EMPALME 70 LEGRAND',222,20,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89322','CAJA EMPALME 160 x 135',362,8,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89333','CAJA EMPALME 220 x 170 LEGRAND',459,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89365','CAJA EMPALME 80 LEGRAND',1456,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L89821','CAJA EMPALME 100 x 100 LEGRAND',102,23,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85546','TECLA DIFUSORES LEGRAND BRONCE',174,13,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85547','TECLA BASE TT LATERAL LEGRANG DIP',289,14,NULL);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85650','TECLA C/C LEGRANG DIPLOMAT BLANCO',255,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85651','TOMA DE CORRIENTE LEGRAND DIPLOMA',259,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85660','CORTACIRCUITO LEGRANG DIPLOMAT',252,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85661','TOMA DE CORRIENTE NORMAL LEGRANG',246,10,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85664','TOMA CORRIENTE DESPL TT LEGRANG D',312,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85683','TOMA DE TELEFONO LEGRANG DIPLOMAT',407,7,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85684','TECLA BASE LEGRANG DIPLOMAT BLANC',675,4,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85685','TECLA BASE LEGRANG DIPLOMAT MARFI',947,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85706','TECLA BASE TT LATERAL LEGRANG DIP',525,6,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85725','TECLA BASE LATERAL LEGRANG DIPLOM',102,26,14);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85803','TOMA TELEFONO BLANCO LEGRAND SERI',330,15,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85943','CAJA 1 E. LEGRAND SERIE MOSAIC',658,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86221','CAJA 4 E. LEGRNAD SERIE MOSAIC',490,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L86223','CAJA 6 E. LEGRAND SERIE MOSAIC',234,10,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85545','MARCO LEGRAND 3 ELEMENTOS BRONCE',107,41,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85320','TOMA LATERAL LEGRAND DIPLOMAT',975,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85323','TPMA DESPLAZADA LEGRAND DIPLOMAT',256,16,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85390','TOMA DESPLAZADA LEGRAND DIPLOMAT',43,39,31);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85392','TOMA DESPLAZADA LEGRAND DIPLOMAT',45,76,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85393','TOMA DESPLAZADA LEGRAND DIPLOMAT',68,NULL,38);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85396','TOMA LATERAL LEGRAND DIPLOMAT MOK',80,17,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85397','TOMA LATERAL LEGRAND DIPLOMAT BLA',73,46,39);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85410','MARCO LEGRAND 1 ELEMENTO MARFIL',3464,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85445','MARCO LEGRAND 2 ELEMENTOS MARFIL',393,6,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85447','MARCO LEGRAND 3 ELEMENTOS MARFIL',388,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85450','MARCO LEGRAND 1 ELEMENTO BEIGE',620,7,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85457','MARCO LEGRAND 2 ELEMENTOS BEIGE',434,10,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85458','MARCO LEGRAND 3 ELEMENTOS BEIGE',466,9,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85459','TECLA LEGRAND MARFIL',466,8,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85460','TECLA DOBLE INTERRUPTOR LEGRANG D',434,10,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85487','TECLA LEGRAND BEIGE',388,11,11);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85489','TECLA LEGRAND DIFUSORES MARFIL',379,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85500','TECLA DIFUSORES LEGRAND BEIGE',107,23,16);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85501','MARCO LEGRAND 1 ELEMENTO MOKA',179,24,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85502','MARCO LEGRAND 2 ELEMENTOS MOKA',290,10,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85508','MARCO LEGRAND 3 ELEMENTOS MOKA',112,8,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85509','MARCO LEGRAND 1 ELEMENTO BLANCO',179,9,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85510','MARCO LEGRAND 2 ELEMENTOS BLANCO',327,10,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85512','MARCO LEGRAND 3 ELEMENTOS BLANCO',227,NULL,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85514','TECLA LEGRAN MOKA',289,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85522','TECLA DIFUSORES LEGRAND MOKA',255,6,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85526','TECLA LEGRAND BLANCO',244,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85532','TAPA PARA INTERRUPTOR BLANCO LEGR',250,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85540','TECLA DOBLE LEGRAND DIPROMAT',110,NULL,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85541','MARCO LEGRAND 1 ELEMENTO BRONCE',178,6,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85542','MARCO LEGRAND 2 ELEMENTOS BRONCE',294,7,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85310','TOMA LATERAL LEGRAND DIPLOMAT MAR',426,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85318','TOMA LATERAL LEGRAND DIPLOMAT BEI',233,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76176','PLACA 1 E. LEGRAND SERIE MOSAIC',675,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76177','PLACA 2 E. LEGRNAD SERIE MOSAIC',460,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76179','PLACA 1 E. LEGRAND SERIE MOSAIC',525,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76424','PLACA 2 E. LEGRAND SERIE MOSAIC',483,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76425','PLACA 3 E. LEGRAND SERIE MOSAIC',525,6,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76427','PLACA 4 E. LEGRAND SERIE MOSAIC',525,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77205','PLACA 6 E. LEGRAND SERIE MOSAIC',99,28,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77207','PLACA 6 E. CON VISOR LEGRAND SERI',113,37,19);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77211','PIEZA Y PLACA 6-6 E. LEGRAND SERI',162,NULL,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77220','LAMPARA LEGRAND 220V',53,9,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77251','INTERRUPTOR LEGRANG GALION',97,26,21);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77252','COMUTADOR LEGRANG GALION',80,14,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77253','DOBLE INTERRUPTOR LEGRAND GALION',215,16,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77254','PULSADOR LEGRAN SUPERFICIE',214,9,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77255','TOMA CORRIENTE SUPERFICIE LEGRAND',133,28,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77256','BASE ENCHUFE TT LEGRAND SUPERFICI',180,NULL,23);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77258','INTERRUPTOR LEGRAND DIPLOMAT',232,13,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77708','COMUTADOR LEGRAND DIPLOMAT',520,7,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L77712','DOBLE INTERRUPTOR LEGRAND DIPLOMA',1820,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L78008','CRUZAMIENTO LEGRAND DIPLOMAT',203,NULL,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L83000','PULSADOR LEGRAND DIPLOMAT',433,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L83001','TOMA DE CORRIENTE TT LATERAL LEGR',482,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L83002','DOBLE COMUTADOR LEGRAND DIPLOMAT',765,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L83005','ADACTADOR LEGRAND LUMINOSO',550,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L83021','DIFUSOR LEGRNAD INCOLORO',308,13,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L83029','DIFUSOR PARA TAPA LEGRAND SERIE D',564,5,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85300','ADACTADOR LEGRAND ROJO',391,8,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85301','DIFUSOR LEGRAND ROJO TIMBRE',470,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85302','DIFUSOR LEGRAND ROJO LUZ',566,4,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L85304','REGULADOR DE LUZ 600W LEGRAND DIP',674,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L57368','CRUZAMIENTO 1 M. LEGRAND SERIE MO',1040,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L57428','BASE ENCHUFE NORMAL 1 M. LEGRAND',836,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L57429','BASE ENCHUFE NORMAL 2 M. LEGRAND',1020,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L58068','BASE ENCHUFE T.T. 2 M. LEGRAND SE',1130,4,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L58128','BASE ENCHUFE SCHUCO 2 M. LEGRAND',1040,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76010','BASE ENCHUFE T.T. 1 M. LEGRAND SE',278,14,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76011','TOMA ALTAVOZ 1 M. LEGRAND SERIE M',308,NULL,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76014','TOMA TELEFONO 2 M. LEGRAND SERIE',363,13,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76015','CORTACIRCUITOS 10A. 2M. LEGRAND S',396,6,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76041','CORTACIRCUITOS 10 A. 1 M. LEGRAND',782,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76046','CORTACIRCUITOS 16A. 1 M. LEGRAND',897,5,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76104','PULSADOR PUS LEGRANG MOSAIC',275,8,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76114','PULSADOR LEGRAND MOSAIC CAMPANA P',327,NULL,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76121','PULSADOR LEGRAND MOSAIC LUZ PLANO',226,14,9);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76126','PIEZA 3 E. LEGRAND SERIE MOSAIC',365,7,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76138','PIEZA 4 E. LEGRAND SERIE MOSAIC',189,20,18);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76151','PIEZA 6 E. LEGRAND SERIE MOSAIC',264,7,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L76165','PIEZA 1 E. LEGRAND SERIE MOSAIC',700,7,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L46164','CLAVIJA 20 A. LEGRAND',2089,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L49107','BASE ENCHUFE 32 A. LEGRAND',1605,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L49119','BASES LEGRAND 16A INCLINADA',2790,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L49842','BASE AEREA LEGRAND III-N-TT',4940,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L50510','BASE LEGRAND 3P+T 16A EMPOTRAR CU',410,6,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L50512','CLAVIJA LEGRAND 16',510,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L50540','CLAVIJA LEGRAND III-N-TT',606,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L55152','BASE LEGRAND 3P+T 32 A EMPOTRAR C',513,9,8);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L55423','CLAVIJA LEGRAND 32A III-TT',476,9,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L55432','INTERRUPTOR 1 M. LEGRAND SERIE MO',618,7,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L55802','CONMUTADOR 1 M. LEGRAND SERIE MOS',928,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L55812','INTERRUPTOR 2 M. LEGRAND SERIE MO',1154,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L57308','CONMUTADOR 2 M. LEGRAND SERIE MOS',1075,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L57309','CRUZAMIENTO 2 M. LEGRAND SERIE MO',1390,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17065','BASES DE FUSIBLE CUCHILLAS T4',1350,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17355','GRAPILLON  HASTA 3 x 1.5',1195,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17555','COLLARINES LEGRAND L180',1735,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17560','COLLARINES LEGRAND L280',1735,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17565','BORNAS 2 x 6 LEGRAND',1735,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17570','BORNAS 2 x 10 LEGRAND',1845,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17575','BORNAS 2 x 16 LEGRAND',1845,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17804','BORNAS 2 x 25 LEGRAND',1035,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L18100','BORNAS 2 x 35 LEGRAND',3856,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L18104','BORNAS CLIC 2 x 30 LEGRAND',2452,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L18500','BORNAS CLIC 2 x 50 LEGRAND',88617,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L31577','BORNAS CLIC 2 x 75 LEGRAND',5,448,326);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L32038','BORNAS CLIC 2 x 120 LEGRAND',6,372,141);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L32043','REGLETAS  4 mm LEGRAND',11,41,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34000','REGLETAS 6 mm LEGRAND',399,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34001','REGLETAS 10 mm LEGRAND',501,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34002','REGLETAS 16 mm LEGRAND',548,4,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34003','REGLETAS 25 mm LEGRAND',1260,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34004','PUENTE TIERRA LEGRAND',1536,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34043','BORNAS LEGRAN 6MM',305,11,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34044','BORNAS RIEL LEGRAND 25M/M',477,7,4);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34045','BORNAS DE RIEL LEGRAND 35 M/M',855,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34047','BORNAS DE RIEL LEGRAND 70 M/M',3234,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34211','BORNAS DE RIEL LEGRAND TOMA TIERR',102,11,5);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34213','BORNAS DE RIEL LEGRAND TOMA DE TI',109,45,13);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34215','IMTERRUPTOR LEGRAND III SALIENTE',139,25,22);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34217','TELERRUPTOR LEGRAND',221,19,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34219','TELERRUPTOR LEGRAND',602,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L34389','INTERRUPTOR CREPUSCULAR LEGRAND',608,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L37062','BASE MULTIPRE 4 BASES LEGRAN',102,46,41);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L37066','4 BASES DE ENCHUFE LEGRANG SUPERF',227,NULL,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L37068','BASE TIPRE LEGRANG SUPERFICIE',286,5,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L37099','CLAVIJA LEGRAND II POLOS 20A',1136,4,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17060','PUENTE NEUTRO LEGRAND T3',1350,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L37374','BASE LEGRAND II POLOS TT 25 A',352,14,12);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L37378','BASE ENCHUFE 20 A. LEGRAND',570,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17000','PUENTE NEUTRO LEGRAND T2',1575,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L17055','BASES DE FUSIBLE CUCHILLAS T3',1330,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMFN25L','CARTUCHO FUSIBLE LEGRAND 6,3X6 6A',2133,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMFN32L','CARTUCHO FUSIBLE LEGRAND 6,3X23 1',2213,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMFN40L','CARTUCHOS FUSIBLES OO 6A LEGRAN',2964,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMFN5L','CARTUCHO FUSIBLE LEGRAND 10,3X38',2457,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L03240','CARTUCHO FUSIBLE LEGRAND 14X51 40',625,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L03701','CARTUCHO FUSIBLE LEGRAND 14X51 50',3141,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L03752','CARTUCHO FUSIBLE LEGRAND 22X58 40',4650,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L03753','CARTUCHO FUSIBLE LEGRAND 22X58 63',6655,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L03755','CARTUCHO FUSIBLE LEGRAND T2 80 A',6971,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L10304','CARTUCHO FUSIBLE LEGRAND T2 100 A',144,29,24);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L10306','BASES DE CUCHILLAS LEGRAND T00',144,15,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L10310','CARTUCHO FUSIBLE LEGRAND T00 63 A',144,24,17);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L123010','CARTUCHO FUSIBLE LEGRAND T00 100',45,36,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L13420','CARTUCHO FUSIBLE LEGRAND T00 125',80,17,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L14340','BASES DE FUSIBLES CUCHILLAS T0',85,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L14350','CARTUCHO FUSIBLE LEGRAND T0 100 A',110,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L15340','CARTUCHO FUSIBLE LEGRAND T0 125 A',175,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L15363','CARTUCHO FUSIBLE LEGRAND T0 160 A',175,27,24);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L15380','PUENTE NEUTRO LEGRAND T00',184,14,6);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L15396','BASE FUSIBLES CUCHILLAS LEGRAND T',204,18,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16000','CARTUCHIO FUSIBLE LEGRAND 160 A T',694,6,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16035','CARTUCHO FUSIBLE LEGRAND T1 160 A',695,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16045','CARTUCHO FUSIBLE LEGRAND T1 250 A',705,5,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16050','CARTUCHO FUSIBLE LEGRNAD 160 T1',575,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16500','CARTUCHO FUSIBLE LEGRAND T2 160 A',1025,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16545','CARTUCHO FUSIBLE LEGRAND T2 200 A',980,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16550','CARTUCHO FUSIBLE LEGRAND T2 250 A',980,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16555','CARTUCHO FUSIBLE LEGRAND T2 315 A',980,3,3);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('L16804','CARTUCHO FUSIBLE LEGRAND T2 400 A',504,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P15L','CONTACTOR GARDY 20A III',4424,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P15V','CONTACTOR GARDY 40A II',6514,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P20L','CONTACTOR GARDY 40A III',5424,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P20V','DESCONECTADOR GARDY III 160 A',6514,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P25L','INTERRUPTOR MAGNETOTERMICO F-N, 1',5424,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P25V','INTERRUPTOR MAGNETOTERMICO  F-N,',6514,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P32L','INTERRUPTOR MAGNETOTERMICO F-N, 2',5624,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P32V','INTERRUPTOR MAGNETOTERMICO F-N, 2',8544,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P40L','INTERRUPTOR MAGNETOTERMICO F-N, 3',7040,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P5L','INTERRUPTOR MAGNETOTERMICO	F-N,',5722,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMC20III','INTERRUPTOR MAGNETOTERMICO F-N, 5',4180,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMC40II','BASE T.T. LATERAL RIEL LEGRAND',5156,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMC40III','TEMPORIZADOR LEGRANG',7803,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMD160','INTERRUPTOR HORARIO LEGRAND',9652,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMFN10L','INTERRUPTOR HORARIO CON RESERVA L',2133,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMFN15L','INTERRUPTOR HORARIO POGRAMA SEMAN',2133,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IMFN20L','CARTUCHO FUSIBLE LEGRA 6,3X23 4 A',2133,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P10V','INTERRUPTOR MAGNETOTERMICO 50 A U',4376,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P15L','INTERRUPTOR MAGNETOTERMICO  3P, 5',3704,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P20L','INTERRUPTOR MAGNETOTERMICO  4P, 1',3704,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P20V','INTERRUPTOR MAGNETOTERMICO  4P, 1',4376,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P25V','INTERRUPTOR MAGNETOTERMICO  4P, 2',4376,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P32L','INTERRUPTOR MAGNETOTERMICO  4P, 2',3847,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P32V','INTERRUPTOR MAGNETOTERMICO  4P, 2',4494,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P40L','INTERRUPTOR MAGNETOTERMICO  4P, 2',4940,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P50U','INTERRUPTOR MAGNETOTERMICO  4P, 3',8550,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P5L','INTERRUPTOR MAGNETOTERMICO	4P, 3',3916,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P10L','INTERRUPTOR MAGNETOTERMICO  4P, 4',5424,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM4P10V','INTERRUPTOR MAGNETOTERMICO  4P, 5',6514,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P5L','INTERRUPTOR MAGNETOTERMICO	3P, 3',2534,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM3P10L','INTERRUPTOR MAGNETOTERMICO  3P, 4',3704,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID440300','INTERRUPTOR MAGNETOTERMICO  1P, 2',13250,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID46330','INTERRUPTOR MAGNETOTERMICO  1P, 3',34000,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID463300','INTERRUPTOR MAGNETOTERMICO  1P, 3',17480,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P10L','INTERRUPTOR MAGNETOTERMICO  1P, 5',1145,3,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P10V','MAGNETOTERMICO 2 POLOS 15 A',1345,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P15L','MAGNETOTERMICO 2 POLOS 25 A',1145,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P15V','MAGNETOTERMICO 2 POLOS 30 A',1345,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P20L','INTERRUPTOR MAGNETOTERMICO  2P, 1',1145,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P20V','INTERRUPTOR MAGNETOTERMICO  2P, 1',1345,3,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P25V','INTERRUPTOR MAGNETOTERMICO  2P, 1',1343,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P32L','INTERRUPTOR MAGNETOTERMICO  2P, 2',1395,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P32V','INTERRUPTOR MAGNETOTERMICO  2P, 2',1482,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM1P5L','INTERRUPTOR MAGNETOTERMICO	2P, 2',1330,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2F15','INTERRUPTOR MAGNETOTERMICO	2P, 2',2730,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2F25','INTERRUPTOR MAGNETOTERMICO	2P, 3',2730,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2F30','INTERRUPTOR MAGNETOTERMICO	2P, 3',2876,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P10L','INTERRUPTOR MAGNETOTERMICO  2P, 4',2470,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P10V','INTERRUPTOR MAGNETOTERMICO  2P, 5',3010,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P15L','INTERRUPTOR MAGNETOTERMICO  3P, 1',2397,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P15V','INTERRUPTOR MAGNETOTERMICO  3P, 1',3010,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P20L','INTERRUPTOR MAGNETOTERMICO  3P, 1',2470,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P20V','INTERRUPTOR MAGNETOTERMICO  3P, 1',2901,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P25L','INTERRUPTOR MAGNETOTERMICO  3P, 2',2470,2,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P25V','INTERRUPTOR MAGNETOTERMICO  3P, 2',2901,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P32L','INTERRUPTOR MAGNETOTERMICO  3P, 2',2825,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P32V','INTERRUPTOR MAGNETOTERMICO  3P, 2',3012,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('IM2P40L','INTERRUPTOR MAGNETOTERMICO  3P, 3',3234,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID24030','INTERRUPTOR MAGNETOTERMICO  1P, 1',8385,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID24030N','INTERRUPTOR MAGNETOTERMICO  1P, 1',1660,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID42530','INTERRUPTOR MAGNETOTERMICO  1P, 2',14535,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID425300','INTERRUPTOR MAGNETOTERMICO  1P, 2',12285,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('ID44030','INTERRUPTOR MAGNETOTERMICO  1P, 2',15670,1,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CM4X1.5','PIREPOL N	 1 x 6',209,7,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CM4X2.5','PARALELO	2 x 0.5',289,2,1);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CN1X1','PARALELO   2 x 0.7',14.2,320,175);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CN1X1.5','PARALELO	2 x 1',19.3,15,7);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CN1X10','PARALELO   2 x 1.5',128.4,28,19);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CN1X16','PARALELO   2 x 2.5',250,13,10);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CN1X2.5','PARALELO	3 x 0.75',32,52,NULL);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CN1X25','PARALELO   3 x 1',406,5,2);


insert into articulos (codart, descrip, precio, stock, stock_min) values ('CN1X35','PARALELO   3 x 1.5',562,1,1);
commit;
