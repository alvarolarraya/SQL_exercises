insert into pueblos (codpue, nombre, codpro) values ('00021','AQON DE MONCAYO','50');


insert into pueblos (codpue, nombre, codpro) values ('01651','ALGAR (EL)','03');


insert into pueblos (codpue, nombre, codpro) values ('01839','ALMARCHA (LA)','16');


insert into pueblos (codpue, nombre, codpro) values ('02050','ALTERO DE MOMPOY','46');


insert into pueblos (codpue, nombre, codpro) values ('02814','ARAYA','12');


insert into pueblos (codpue, nombre, codpro) values ('03061','ARENAL (EL)','07');


insert into pueblos (codpue, nombre, codpro) values ('04033','AUZOTXIKIA','20');


insert into pueblos (codpue, nombre, codpro) values ('05495','BASANOVA (LA)','12');


insert into pueblos (codpue, nombre, codpro) values ('05754','BEG','02');


insert into pueblos (codpue, nombre, codpro) values ('05998','BENAMAHOMA','11');


insert into pueblos (codpue, nombre, codpro) values ('06362','BERROCALES DEL JARAMA (LOS)','28');


insert into pueblos (codpue, nombre, codpro) values ('06571','BINIAMAR','07');


insert into pueblos (codpue, nombre, codpro) values ('06579','BINISALEM','07');


insert into pueblos (codpue, nombre, codpro) values ('06905','BONRETORN','43');


insert into pueblos (codpue, nombre, codpro) values ('07625','BUGARRA','46');


insert into pueblos (codpue, nombre, codpro) values ('07766','BURRIANA','12');


insert into pueblos (codpue, nombre, codpro) values ('07951','CAQADA (LA)','16');


insert into pueblos (codpue, nombre, codpro) values ('08751','CALA LLITERAS','07');


insert into pueblos (codpue, nombre, codpro) values ('08764','CALA ROMANA','43');


insert into pueblos (codpue, nombre, codpro) values ('08820','CALATAYUD','50');


insert into pueblos (codpue, nombre, codpro) values ('08993','CALLUS','08');


insert into pueblos (codpue, nombre, codpro) values ('09248','CAMINO DE PARACUELLOS','28');


insert into pueblos (codpue, nombre, codpro) values ('10917','CARNICERA','33');


insert into pueblos (codpue, nombre, codpro) values ('11024','CARRASCA (LA)','46');


insert into pueblos (codpue, nombre, codpro) values ('11408','CASA GRANDE','44');


insert into pueblos (codpue, nombre, codpro) values ('12060','CASILLAS (LAS)','14');


insert into pueblos (codpue, nombre, codpro) values ('12309','CASTELLON','12');


insert into pueblos (codpue, nombre, codpro) values ('13003','CELADA','24');


insert into pueblos (codpue, nombre, codpro) values ('13541','CEUTA (CIUDAD)','51');


insert into pueblos (codpue, nombre, codpro) values ('13996','CIADUEQA','42');


insert into pueblos (codpue, nombre, codpro) values ('14140','CINT (EL)','08');


insert into pueblos (codpue, nombre, codpro) values ('14637','COLOMER CUADRA','25');


insert into pueblos (codpue, nombre, codpro) values ('15424','CORTIJO (EL)','28');


insert into pueblos (codpue, nombre, codpro) values ('15619','COSTA DE LOS PINOS','07');


insert into pueblos (codpue, nombre, codpro) values ('16745','CURRELO (O)','36');


insert into pueblos (codpue, nombre, codpro) values ('16926','DEHESA DE VILLANDRANDO','34');


insert into pueblos (codpue, nombre, codpro) values ('17791','ENCINAS (LAS)','28');


insert into pueblos (codpue, nombre, codpro) values ('17859','ENRAMONA','12');


insert into pueblos (codpue, nombre, codpro) values ('20267','FORMICHE ALTO','44');


insert into pueblos (codpue, nombre, codpro) values ('20295','FORNADEIROS (SAN PEDRO)','32');


insert into pueblos (codpue, nombre, codpro) values ('20875','FUENDEJALON','50');


insert into pueblos (codpue, nombre, codpro) values ('21104','FUENTES DE JILOCA','50');


insert into pueblos (codpue, nombre, codpro) values ('21355','GALILEA','07');


insert into pueblos (codpue, nombre, codpro) values ('21819','GENESTOSA','24');


insert into pueblos (codpue, nombre, codpro) values ('24263','IZANA','38');


insert into pueblos (codpue, nombre, codpro) values ('25630','LENTEJI','18');


insert into pueblos (codpue, nombre, codpro) values ('26289','LLUCALARY','07');


insert into pueblos (codpue, nombre, codpro) values ('27215','MAHAVE','26');


insert into pueblos (codpue, nombre, codpro) values ('27861','MARRATXINET','07');


insert into pueblos (codpue, nombre, codpro) values ('27948','MARTINEZ (LOS)','04');


insert into pueblos (codpue, nombre, codpro) values ('28023','MAS D''EN ROCA','08');


insert into pueblos (codpue, nombre, codpro) values ('28097','MAS DEL SECO','12');


insert into pueblos (codpue, nombre, codpro) values ('28370','MATALUENGA','24');


insert into pueblos (codpue, nombre, codpro) values ('28623','MECO','28');


insert into pueblos (codpue, nombre, codpro) values ('29149','MIQANA','03');


insert into pueblos (codpue, nombre, codpro) values ('30586','MORERA DE MONTSANT (LA)','43');


insert into pueblos (codpue, nombre, codpro) values ('30996','MUGUETA','31');


insert into pueblos (codpue, nombre, codpro) values ('31195','MURUZABAL','31');


insert into pueblos (codpue, nombre, codpro) values ('31289','NARANJEROS (LOS)','38');


insert into pueblos (codpue, nombre, codpro) values ('31481','NAVARREDONDA DE LA RINCONADA','37');


insert into pueblos (codpue, nombre, codpro) values ('31527','NAVASEQUILLA','05');


insert into pueblos (codpue, nombre, codpro) values ('31982','NOVELE','46');


insert into pueblos (codpue, nombre, codpro) values ('32003','NOVILLAS','50');


insert into pueblos (codpue, nombre, codpro) values ('32093','NULES','12');


insert into pueblos (codpue, nombre, codpro) values ('32101','NURTAL-CDA. FARANDOLA','46');


insert into pueblos (codpue, nombre, codpro) values ('32112','OASIS','35');


insert into pueblos (codpue, nombre, codpro) values ('32419','OLMOS (LOS)','44');


insert into pueblos (codpue, nombre, codpro) values ('32457','OMAQAS (LAS)','24');


insert into pueblos (codpue, nombre, codpro) values ('32550','ORBITA','05');


insert into pueblos (codpue, nombre, codpro) values ('33246','PAIPORTA','46');


insert into pueblos (codpue, nombre, codpro) values ('33534','PALOS DE LA FRONTERA','21');


insert into pueblos (codpue, nombre, codpro) values ('36300','PLANASSA (LA)','08');


insert into pueblos (codpue, nombre, codpro) values ('37953','PUEBLA DE SAN MIGUEL','46');


insert into pueblos (codpue, nombre, codpro) values ('38168','PUERTO (EL)','07');


insert into pueblos (codpue, nombre, codpro) values ('38576','QUESADA','23');


insert into pueblos (codpue, nombre, codpro) values ('39063','RAIGUERO (EL)','03');


insert into pueblos (codpue, nombre, codpro) values ('39486','REBON','15');


insert into pueblos (codpue, nombre, codpro) values ('40066','RENTERIA','20');


insert into pueblos (codpue, nombre, codpro) values ('40332','RIAHUELAS','40');


insert into pueblos (codpue, nombre, codpro) values ('41550','ROSAMIANA','33');


insert into pueblos (codpue, nombre, codpro) values ('42277','SALINAS (LAS)','19');


insert into pueblos (codpue, nombre, codpro) values ('42366','SALTO DE TORREJON','10');


insert into pueblos (codpue, nombre, codpro) values ('42567','SAN ANTONIO DE PORMANY','07');


insert into pueblos (codpue, nombre, codpro) values ('43446','SAN SALVADOR','39');


insert into pueblos (codpue, nombre, codpro) values ('45004','SAX','03');


insert into pueblos (codpue, nombre, codpro) values ('46278','SOMOSAGUAS (CENTRO)','28');


insert into pueblos (codpue, nombre, codpro) values ('46302','SON DEL PUERTO','44');


insert into pueblos (codpue, nombre, codpro) values ('46305','SON FERRER','07');


insert into pueblos (codpue, nombre, codpro) values ('46332','SONEJA','12');


insert into pueblos (codpue, nombre, codpro) values ('46876','TABLADA DE VILLADIEGO','09');


insert into pueblos (codpue, nombre, codpro) values ('47218','TARTANEDO','19');


insert into pueblos (codpue, nombre, codpro) values ('47731','TIURANA','25');


insert into pueblos (codpue, nombre, codpro) values ('47881','TOMILLERAS (LAS)','28');


insert into pueblos (codpue, nombre, codpro) values ('47974','TORIL','44');


insert into pueblos (codpue, nombre, codpro) values ('48037','TORO (EL)','12');


insert into pueblos (codpue, nombre, codpro) values ('48192','TORRE-BELTRAN','12');


insert into pueblos (codpue, nombre, codpro) values ('48367','TORREQUINTO','41');


insert into pueblos (codpue, nombre, codpro) values ('49180','TURIS','46');


insert into pueblos (codpue, nombre, codpro) values ('49866','VALDEARENAS','19');


insert into pueblos (codpue, nombre, codpro) values ('50500','VALLS DE TORRUELLA','08');


insert into pueblos (codpue, nombre, codpro) values ('50646','VARA DE REY','16');


insert into pueblos (codpue, nombre, codpro) values ('53027','VILLAMARTIN','11');


insert into pueblos (codpue, nombre, codpro) values ('53596','VILLARREAL','12');


insert into pueblos (codpue, nombre, codpro) values ('53608','VILLARROAQE','24');

commit;