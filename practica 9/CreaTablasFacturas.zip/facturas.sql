insert into facturas (codfac, fecha, codcli, iva, dto) values (1,to_date('13-06-2019','dd-mm-yyyy'),219,7,14);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (2,to_date('16-11-2020','dd-mm-yyyy'),252,7,0);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (3,to_date('25-04-2017','dd-mm-yyyy'),48,7,NULL);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (4,to_date('21-12-2019','dd-mm-yyyy'),255,7,0);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (5,to_date('13-04-2019','dd-mm-yyyy'),6,0,NULL);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (6,to_date('01-01-2019','dd-mm-yyyy'),198,16,1);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (7,to_date('05-12-2020','dd-mm-yyyy'),42,16,NULL);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (8,to_date('16-02-2018','dd-mm-yyyy'),300,0,21);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (9,to_date('22-10-2020','dd-mm-yyyy'),201,16,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (10,to_date('26-03-2020','dd-mm-yyyy'),261,7,2);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (11,to_date('06-07-2018','dd-mm-yyyy'),12,16,20);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (12,to_date('12-06-2020','dd-mm-yyyy'),45,0,2);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (13,to_date('23-09-2017','dd-mm-yyyy'),57,16,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (14,to_date('04-01-2020','dd-mm-yyyy'),219,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (15,to_date('29-07-2019','dd-mm-yyyy'),192,16,7);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (16,to_date('03-09-2016','dd-mm-yyyy'),207,16,17);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (17,to_date('04-06-2020','dd-mm-yyyy'),141,7,4);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (18,to_date('10-12-2020','dd-mm-yyyy'),69,16,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (19,to_date('05-11-2016','dd-mm-yyyy'),258,16,16);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (20,to_date('03-09-2018','dd-mm-yyyy'),279,0,0);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (21,to_date('06-03-2017','dd-mm-yyyy'),54,0,1);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (22,to_date('05-07-2017','dd-mm-yyyy'),144,0,23);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (23,to_date('27-07-2016','dd-mm-yyyy'),183,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (24,to_date('11-08-2017','dd-mm-yyyy'),87,16,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (25,to_date('31-10-2019','dd-mm-yyyy'),93,16,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (26,to_date('30-12-2019','dd-mm-yyyy'),99,0,0);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (27,to_date('05-04-2019','dd-mm-yyyy'),150,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (28,to_date('06-04-2020','dd-mm-yyyy'),273,0,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (29,to_date('07-11-2018','dd-mm-yyyy'),63,16,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (30,to_date('18-08-2020','dd-mm-yyyy'),258,7,16);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (31,to_date('10-02-2018','dd-mm-yyyy'),120,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (32,to_date('07-09-2017','dd-mm-yyyy'),228,0,0);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (33,to_date('23-06-2016','dd-mm-yyyy'),24,0,7);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (34,to_date('14-10-2019','dd-mm-yyyy'),207,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (35,to_date('25-01-2016','dd-mm-yyyy'),234,16,20);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (36,to_date('11-12-2017','dd-mm-yyyy'),180,7,5);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (37,to_date('29-08-2018','dd-mm-yyyy'),150,0,24);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (38,to_date('19-06-2019','dd-mm-yyyy'),228,7,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (39,to_date('18-02-2017','dd-mm-yyyy'),81,16,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (40,to_date('20-10-2020','dd-mm-yyyy'),63,16,25);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (41,to_date('21-06-2020','dd-mm-yyyy'),207,16,25);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (42,to_date('04-01-2018','dd-mm-yyyy'),69,7,0);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (43,to_date('08-05-2016','dd-mm-yyyy'),150,7,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (44,to_date('23-03-2019','dd-mm-yyyy'),108,0,0);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (45,to_date('27-04-2018','dd-mm-yyyy'),180,16,5);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (46,to_date('12-04-2017','dd-mm-yyyy'),42,16,20);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (47,to_date('01-10-2019','dd-mm-yyyy'),99,16,24);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (48,to_date('16-03-2020','dd-mm-yyyy'),180,7,25);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (49,to_date('26-11-2018','dd-mm-yyyy'),177,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (50,to_date('22-11-2016','dd-mm-yyyy'),75,0,22);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (51,to_date('06-07-2019','dd-mm-yyyy'),189,16,8);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (52,to_date('15-10-2017','dd-mm-yyyy'),147,0,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (53,to_date('26-12-2016','dd-mm-yyyy'),150,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (54,to_date('02-07-2019','dd-mm-yyyy'),183,16,13);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (55,to_date('22-08-2016','dd-mm-yyyy'),78,16,20);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (56,to_date('02-12-2020','dd-mm-yyyy'),240,7,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (57,to_date('20-07-2020','dd-mm-yyyy'),231,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (58,to_date('10-08-2017','dd-mm-yyyy'),291,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (59,to_date('05-10-2020','dd-mm-yyyy'),141,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (60,to_date('19-07-2020','dd-mm-yyyy'),252,7,25);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (61,to_date('14-11-2016','dd-mm-yyyy'),54,16,8);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (62,to_date('04-04-2018','dd-mm-yyyy'),192,0,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (63,to_date('24-06-2020','dd-mm-yyyy'),273,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (64,to_date('08-04-2016','dd-mm-yyyy'),108,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (65,to_date('04-09-2018','dd-mm-yyyy'),36,16,17);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (66,to_date('10-09-2020','dd-mm-yyyy'),99,16,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (67,to_date('23-10-2020','dd-mm-yyyy'),159,7,19);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (68,to_date('06-08-2018','dd-mm-yyyy'),57,16,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (69,to_date('12-12-2017','dd-mm-yyyy'),219,7,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (70,to_date('08-08-2020','dd-mm-yyyy'),183,7,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (71,to_date('24-01-2018','dd-mm-yyyy'),267,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (72,to_date('01-11-2017','dd-mm-yyyy'),192,16,10);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (73,to_date('05-07-2016','dd-mm-yyyy'),126,0,11);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (74,to_date('21-05-2017','dd-mm-yyyy'),111,7,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (75,to_date('24-09-2018','dd-mm-yyyy'),261,0,NULL);    
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (76,to_date('14-10-2017','dd-mm-yyyy'),294,16,21);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (77,to_date('07-03-2017','dd-mm-yyyy'),102,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (78,to_date('15-03-2018','dd-mm-yyyy'),213,7,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (79,to_date('01-05-2020','dd-mm-yyyy'),243,16,19);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (80,to_date('24-08-2019','dd-mm-yyyy'),201,16,19);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (81,to_date('02-05-2019','dd-mm-yyyy'),60,16,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (82,to_date('12-11-2018','dd-mm-yyyy'),282,7,0);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (83,to_date('14-07-2016','dd-mm-yyyy'),201,7,24);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (84,to_date('02-07-2016','dd-mm-yyyy'),243,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (85,to_date('23-08-2018','dd-mm-yyyy'),258,7,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (86,to_date('22-01-2016','dd-mm-yyyy'),120,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (87,to_date('22-12-2016','dd-mm-yyyy'),297,7,12);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (88,to_date('20-08-2019','dd-mm-yyyy'),111,16,25);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (89,to_date('10-09-2017','dd-mm-yyyy'),138,16,2);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (90,to_date('02-09-2016','dd-mm-yyyy'),81,16,16);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (91,to_date('23-11-2020','dd-mm-yyyy'),189,0,NULL);    
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (92,to_date('01-09-2018','dd-mm-yyyy'),162,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (93,to_date('12-08-2020','dd-mm-yyyy'),45,0,6);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (94,to_date('19-12-2020','dd-mm-yyyy'),45,7,0);           
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (95,to_date('13-06-2017','dd-mm-yyyy'),162,7,4);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (96,to_date('01-06-2019','dd-mm-yyyy'),147,7,1);          
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (97,to_date('26-05-2018','dd-mm-yyyy'),168,7,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (98,to_date('01-07-2020','dd-mm-yyyy'),135,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (99,to_date('15-04-2018','dd-mm-yyyy'),117,7,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (100,to_date('20-09-2017','dd-mm-yyyy'),159,7,14);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (101,to_date('03-02-2017','dd-mm-yyyy'),228,0,9);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (102,to_date('06-11-2019','dd-mm-yyyy'),159,16,4);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (103,to_date('16-06-2019','dd-mm-yyyy'),96,0,NULL);       
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (104,to_date('02-05-2018','dd-mm-yyyy'),171,0,0);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (105,to_date('02-03-2018','dd-mm-yyyy'),27,16,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (106,to_date('25-11-2017','dd-mm-yyyy'),15,16,0);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (107,to_date('07-08-2020','dd-mm-yyyy'),159,0,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (108,to_date('06-04-2018','dd-mm-yyyy'),174,7,24);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (109,to_date('23-08-2020','dd-mm-yyyy'),207,7,21);        
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (110,to_date('02-12-2017','dd-mm-yyyy'),27,0,15);         
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (111,to_date('10-03-2016','dd-mm-yyyy'),264,7,NULL);      
                                                                                                                 
                                                                                                                        
insert into facturas (codfac, fecha, codcli, iva, dto) values (112,to_date('26-05-2020','dd-mm-yyyy'),201,16,0);        

commit;                                                                                                                 
                                                                                                                        