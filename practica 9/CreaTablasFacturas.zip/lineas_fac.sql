insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (1,1,3,'IMD160',7239,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (1,2,2,'UCM8',3439,23);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (1,3,11,'VI532E',63,13);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (1,4,4,'L50512',477,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (2,2,6,'LA1440EM',356,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (2,3,3,'N5022',380,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (2,4,6,'IMFN40L',1112,23);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (2,5,10,'L85706',492,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (2,6,4,'S3162031',183,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (3,1,5,'IM1P10L',501,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (3,2,1,'TNF13.5',39,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (3,3,11,'L77220',51,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,1,3,'LAR63C',180,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,2,6,'LAR400',1763,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,3,9,'LAF18L',392,17);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,4,11,'L17560',759,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,5,7,'LAVC9',1144,8);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,6,12,'L34045',321,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,7,8,'L83005',275,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,9,6,'P1031',144,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (4,10,4,'L85540',102,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,1,12,'THC36',284,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,2,10,'L85302',212,8);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,3,8,'P1044',93,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,4,8,'IM2F30',2697,17);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,5,2,'L77253',81,4);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,6,12,'LAV250',2391,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,7,5,'LAF40C',525,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (5,9,3,'L37099',497,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (6,1,7,'L55432',309,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (6,2,2,'P1031',144,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (6,3,5,'T4588',281,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (6,4,3,'T4501',186,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (6,5,4,'L86231',467,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (6,6,10,'LA2760EM',72,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (7,1,5,'IM1P15V',588,11);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (7,2,1,'SATF5',4575,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (8,1,10,'TSP29',441,16);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (8,2,11,'ORBILUX',4995,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (8,5,11,'LAE100',32,19);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (8,6,9,'L34211',45,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (8,7,5,'L85508',42,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (8,8,10,'L85510',246,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (9,1,7,'L34043',114,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (9,2,7,'T4750',404,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (9,3,2,'L57308',538,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (9,4,6,'ZN5173B',228,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (9,5,7,'L91812',639,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,1,3,'LAR40',366,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,2,-8,'L85508',84,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,3,12,'N5004',203,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,4,6,'T1001',15,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,5,6,'N5088',95,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,6,6,'VI831E',1050,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,7,5,'LAR65',375,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,8,10,'LAV400',1350,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (10,9,2,'L55423',208,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (11,1,12,'ORC72H',3180,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (11,3,1,'S3125131',748,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (12,1,3,'LA1425EM',42,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (12,2,10,'N5008',206,23);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (12,3,1,'T4522',336,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,1,1,'LAPT',45,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,2,7,'N8019BA',674,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,3,6,'L76046',840,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,4,1,'S3163032',166,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,5,7,'IMD160',4826,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,6,5,'LA40',131,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,7,9,'T4500',54,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,8,5,'L46164',1959,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (13,9,6,'VI727S',365,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (14,2,-1,'LAPC32L',2713,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (14,3,4,'N8019BA',590,17);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (14,4,10,'ZNP3L',8925,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (14,5,6,'TLFXK2',18048,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (14,6,12,'RV400',1575,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (15,1,3,'L37062',51,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (15,3,6,'L123010',20,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,1,8,'B932B',188,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,2,3,'LADU16',871,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,3,6,'IMFN32L',1107,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,4,7,'L50540',303,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,5,7,'TFM36',81,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,6,6,'T4588',281,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,7,4,'L85457',217,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,8,6,'TFM13.5',16,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (16,9,4,'L10310',108,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (17,1,3,'LLG11',1056,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (17,2,-3,'N8002BA',693,13);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (18,2,12,'N5073',114,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (18,3,8,'VI774S',1248,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (18,4,8,'LATL',153,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (18,5,1,'L55432',465,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (19,1,5,'IMFN10L',933,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (19,2,5,'UCM 7',9795,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (19,3,4,'L17355',1119,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (19,4,8,'L37066',213,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,1,11,'L86231',702,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,3,8,'IM4P10V',6108,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,4,2,'L85547',270,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,5,10,'L15340',77,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,6,9,'VI500',2100,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,7,11,'IM2P20L',1235,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,8,5,'L85542',276,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (20,9,10,'L91800',254,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (21,1,10,'VI546E',450,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (21,3,7,'L77211',153,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (22,1,4,'TFC29',327,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (22,2,2,'CM4X1.5',78,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (22,3,4,'IMFN40L',1297,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (23,2,5,'TE5514',3938,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (23,3,5,'UP250P3',17613,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (23,4,10,'L85803',144,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,1,5,'TFC21',96,19);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,2,12,'TSP29',549,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,3,9,'LARD100',65,19);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,4,6,'TH11',119,13);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,5,4,'L16550',735,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,6,10,'T503',45,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,7,8,'LAMP27D',189,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,8,12,'LAR80',204,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,9,10,'N8001.2',441,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (24,10,9,'L76424',211,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,1,9,'L76177',201,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,2,3,'IM1P25V',1008,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,3,3,'L32038',3,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,4,10,'LAOBYO',675,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,6,3,'T10020',90,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,7,8,'N8100',15,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,8,11,'L76179',197,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,9,6,'LASA60',2993,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (25,10,1,'L85510',246,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (26,1,3,'ORT15',3564,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (26,2,11,'S3149136',451,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (27,1,11,'LAM160',613,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (28,1,2,'VI532E',31,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (28,2,6,'S3125131',561,13);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (28,3,5,'IM3P40L',2470,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (28,4,12,'TC16',10,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (28,5,3,'IM1P10L',429,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (29,1,1,'L15380',138,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (29,3,8,'T4503',534,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (30,1,5,'VI553E',375,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (30,2,5,'ID44030',5876,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,1,7,'L16545',918,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,2,4,'LAF65L',1143,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,3,4,'TE3102',2439,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,4,12,'T10027',426,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,5,4,'UP400P3',18783,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,6,2,'L77712',910,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,7,4,'TLGX2',5675,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (31,8,10,'P504',54,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (32,1,2,'N8088BA',250,11);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (32,2,2,'L86231',702,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (32,3,10,'L37099',852,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (33,1,5,'LAVC18',1525,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,1,8,'N5004',381,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,2,12,'TP200',804,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,3,5,'VI831E',1050,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,5,1,'S3165136',750,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,7,1,'P924',149,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,8,12,'P515',111,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,9,8,'T10020',111,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (34,10,4,'N5073',114,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (35,1,8,'IMFN25L',933,11);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (35,3,12,'IM4P20L',5085,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (35,4,9,'TSF36',846,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (35,5,3,'L17560',759,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (35,6,7,'LAF22C',675,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (36,1,3,'IM4P40L',3080,13);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (36,2,5,'S3144236',564,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (37,1,7,'CPT200',919,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (37,2,9,'ORT15',3564,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (38,1,8,'TC1640',303,19);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (38,3,8,'VI863E',894,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (39,1,5,'N5008',387,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (39,2,7,'TLFX4',3550,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (39,3,12,'UCM3',3605,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (40,1,10,'P913',45,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (40,2,6,'VI741E',284,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (40,3,7,'IM4P10V',2850,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (40,4,5,'UCM2',2108,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (40,5,5,'TRAMI1',1875,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (41,1,1,'L17355',598,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (41,2,8,'L92010',43,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (41,3,5,'L15363',77,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,1,11,'IM4P15L',3318,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,2,-3,'S3143236',246,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,3,1,'IM3P32L',2886,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,4,6,'L85489',190,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,5,11,'UCM 7',9795,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,6,5,'VI832E',1050,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,7,10,'N8003BA',190,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,8,5,'IM3P15L',3474,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (42,9,1,'L89127',210,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (43,1,12,'SI4P25A',2603,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (43,3,8,'S3166131',467,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (43,4,4,'TLFX1N',825,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (43,6,3,'S3110436',514,16);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (43,7,10,'L49119',1046,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (43,8,11,'UCM2',2459,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (43,9,5,'L77211',123,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (44,1,6,'L37062',38,16);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (45,1,11,'L76138',83,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (45,2,9,'ZN5172B',83,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (45,3,6,'L85684',633,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (46,1,5,'L85664',156,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (47,1,3,'L17570',1383,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (48,1,12,'UCM8',2948,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (48,3,2,'CAJA2',2840,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (49,1,2,'ZP515',276,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (49,2,-11,'TLFX1N',825,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (49,3,3,'L77207',42,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (49,4,3,'S3165131',212,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (49,5,8,'L89365',546,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,1,8,'TE5514',3938,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,2,3,'L85320',427,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,3,11,'N5008',155,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,4,5,'L34044',447,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,5,3,'L17555',1302,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,6,12,'VI725S',288,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,7,5,'L34043',228,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,8,7,'UP80A3',3780,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,9,9,'VI533E',93,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (50,10,2,'TH13.5',112,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (51,1,6,'IM3P10L',1389,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (51,2,10,'T10021',40,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (51,3,2,'L34044',357,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (51,4,7,'T1006',528,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,1,7,'L17065',591,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,2,4,'S3120431',375,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,4,1,'IM1P32L',1308,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,5,7,'L85320',915,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,6,1,'L03240',585,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,7,6,'T1010',189,8);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,8,1,'L85685',414,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,9,2,'ZN5108B',180,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (52,10,5,'L15396',89,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,1,10,'VI745E',340,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,2,-6,'L85502',127,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,3,7,'L34000',375,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,4,3,'TC13.5N',2,17);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,5,12,'N8010BA',1278,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,6,4,'N5004',203,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,7,7,'LLTRNS50',393,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (53,8,2,'P695',963,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (54,1,2,'L83005',206,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (55,1,6,'T4440',253,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (56,1,1,'ZP635',498,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (56,2,1,'P504',54,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (56,4,11,'LAPC27',111,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (56,5,9,'L89159',54,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (56,6,11,'N8060',15,17);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (56,7,9,'LAE100',63,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (57,1,12,'TSF9',195,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (57,3,9,'L16035',304,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (57,4,3,'T1003',51,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (57,5,2,'LAR20',183,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (58,1,1,'TNF13.5',22,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (58,2,7,'L85664',294,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (58,3,6,'TC11',7,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (59,1,5,'LA1X40',678,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (59,2,8,'LAR40125',686,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (59,3,6,'LACU300',750,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (59,4,7,'TLFX4',2663,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (60,3,7,'P910',16,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (61,1,1,'RF1X18B',634,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (61,2,10,'L15340',66,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (61,4,6,'ID440300',6625,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (61,5,12,'L83005',516,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (61,6,1,'LAF40',252,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (61,7,11,'L85706',492,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,1,6,'LAR63',118,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,2,-10,'L77712',796,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,3,11,'S3161031',96,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,5,3,'CN1X1.5',18,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,6,2,'IMFN5L',1229,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,7,5,'ME200',984,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,8,1,'P615L',218,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (62,9,9,'L85512',213,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (63,1,10,'N8001.2',504,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (63,2,2,'LAF40C',600,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (63,3,5,'IM3P25V',2188,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (63,4,1,'L15340',132,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (64,2,12,'LAPF1X40',3075,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (65,1,9,'IM3P20V',1915,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (66,1,7,'RF20',280,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (66,2,4,'L17000',1182,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (66,3,10,'N5004L',309,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (66,4,5,'N8072BA',171,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (66,5,12,'VI531E',23,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (66,6,9,'VI531E',39,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (66,7,12,'N8010',473,4);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (67,1,11,'L37099',852,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (68,1,8,'LA2725EC',48,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (68,2,7,'IMD160',7239,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (68,3,12,'LPER100',1050,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (68,4,1,'TC71011',594,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (68,5,3,'L14340',81,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (69,1,2,'TSP13.5',204,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (69,2,8,'UIR160',6950,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (69,3,8,'U3002',344,23);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (69,4,11,'L85508',105,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (69,5,8,'LA2760EC',48,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (69,7,3,'VI774S',582,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (69,8,5,'LPER100',1050,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (70,1,5,'L85502',273,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (70,2,12,'L85683',153,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (71,1,6,'L57429',765,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (71,2,11,'TC16401',80,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (72,2,1,'LATIM2',450,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (73,1,2,'LACU1500',1400,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (73,2,6,'TF13.5',53,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (73,3,12,'IM1P32V',741,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (73,4,10,'LATIM1',518,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,1,12,'UCM 7',13060,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,2,5,'LAMP27D',234,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,3,7,'TP2T',13410,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,4,8,'TSP11',216,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,5,4,'TF13.5',114,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,6,1,'L37099',568,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,7,10,'T4522',196,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,9,3,'ZN5110B',445,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (74,10,3,'UCM4',2850,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (75,1,5,'S3110436',686,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (75,2,12,'T10022',108,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (75,4,10,'ORT16',1346,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (75,5,3,'L17065',675,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (75,6,1,'L58068',424,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (75,7,2,'S3162031',183,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (76,1,9,'LA2740EC',90,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (76,2,11,'TC23',42,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (76,3,10,'LAPC27',56,4);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (76,4,4,'PCMIB',6081,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (77,1,7,'L57429',957,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (77,2,5,'l03755',3686,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (77,3,3,'IM2F25',2559,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (77,4,12,'LA2760EC',42,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (77,5,9,'LA2725EC',72,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (77,6,3,'LA2740EC',42,11);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,1,5,'TC100',60,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,3,9,'S3161032',63,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,4,3,'IM1P15V',588,17);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,5,12,'TNF21',43,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,6,10,'L85532',125,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,7,9,'IM3P32L',2886,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,8,8,'LARD60',60,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,9,7,'ZN5104B',178,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (78,10,10,'IM4P20L',2373,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (79,1,6,'TSF16',315,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (79,2,11,'L85541',168,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (79,3,12,'L85546',76,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (79,4,1,'IM2710',722,4);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (80,1,6,'IMFN32L',2076,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (80,2,2,'VI863E',595,17);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (81,1,3,'TSF11',158,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (81,2,3,'TFM21',45,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (81,3,3,'IM4P15V',4887,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (81,4,1,'TFM29',34,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (81,5,3,'P605',258,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,1,7,'T23932',435,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,3,12,'L83001',241,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,4,7,'L17804',518,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,5,12,'L85526',228,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,6,2,'L89320',207,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,7,1,'CN1X1',12,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,8,2,'VI523E',24,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,9,12,'P695',1650,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (82,10,3,'ORT16',1571,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,3,10,'TFC21',240,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,4,11,'VI847S',1149,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,5,8,'CPT002',155,5);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,6,9,'LAF65',206,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,7,8,'ZP615',161,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,8,9,'S3149136',966,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,9,3,'L49842',2470,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (83,10,3,'L16035',261,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (84,1,2,'P434L',405,14);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (84,2,4,'LAR63',204,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (84,4,12,'ID463300',16389,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (84,5,5,'L76041',732,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (84,6,12,'N8001BA',492,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,1,10,'L91812',639,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,2,1,'VI863E',1116,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,3,1,'S3120436',558,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,4,3,'L85501',168,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,5,11,'VI718S',144,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,6,8,'P635',534,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,7,8,'N8001.2',441,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (85,8,8,'VI523E',28,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (86,1,2,'LAV250',1116,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (86,2,4,'L76427',492,11);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (86,3,11,'P515',237,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (87,1,12,'N5071',75,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (87,2,2,'T4522',196,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (87,3,5,'N8017BA',283,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (87,4,6,'L85943',288,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (87,5,3,'RF40',525,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (87,6,6,'ID44030',11754,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (88,1,10,'N5001',154,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (88,2,6,'N8050BA',338,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (88,3,4,'L34211',51,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (88,4,3,'TSF29',310,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (88,5,10,'S3125136',1401,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (89,1,11,'L89127',105,16);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (89,2,6,'IM2P25V',1269,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (90,1,4,'S3161031',47,1);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (90,2,10,'T1012',79,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (90,3,6,'LAC40',47,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (91,2,3,'CN1X2.5',16,13);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (91,3,11,'LAV125',371,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (91,4,5,'L85725',38,8);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (91,5,6,'TC80',86,19);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (91,6,1,'L57308',1008,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (91,7,4,'LAV400',1575,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (91,8,8,'IMFN5L',921,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (92,1,11,'L92117',684,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (92,2,2,'S3110436',1284,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (92,3,9,'L85447',146,23);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (92,4,2,'RF20',525,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (92,5,10,'IM3P5L',1958,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (92,6,6,'L85447',146,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (93,1,9,'S3120431',438,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (93,2,11,'S3161031',55,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (94,1,11,'L16804',474,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (94,2,3,'TE1401',345,13);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (95,1,5,'TC29',24,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (95,2,11,'L37066',114,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (95,4,8,'LAR1X40',1164,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (95,5,10,'UCM8',7368,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (96,1,4,'L89322',158,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (96,2,2,'L85542',222,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (96,3,11,'L85410',1299,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (96,4,12,'L85684',507,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (96,5,7,'L85310',213,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (96,6,12,'LAMPT14',23,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (96,7,9,'IM2P5L',950,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (97,1,9,'VI833E',700,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (97,2,-8,'IM1P32V',1389,25);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (97,3,9,'TH13.5',96,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (97,4,6,'VI832E',613,7);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (97,5,3,'TLFX1N',1032,19);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (97,6,9,'L85304',337,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,1,10,'N8071BA',55,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,2,9,'S3143231',223,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,3,12,'LA1440EC',42,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,4,4,'L16050',216,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,5,9,'TE1401',302,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,6,1,'LL2X36B',3630,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,7,6,'P615',297,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (98,8,9,'L57309',521,NULL);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (99,2,9,'L76424',363,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (99,3,10,'T10020',45,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (100,1,2,'VI718S',71,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (100,2,5,'LAR1X20',725,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (100,3,9,'S3143236',287,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (100,4,7,'N5004L',246,12);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (101,1,1,'LAM160',1050,19);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (101,2,7,'LLTRNS50',393,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (102,1,3,'B930B',171,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (102,2,4,'LAE100',32,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (102,3,4,'RT1250',750,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (103,1,11,'L16804',252,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (104,1,8,'L77712',683,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (104,2,6,'L85540',55,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (104,4,2,'L57429',383,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (104,5,3,'TF29',139,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (105,1,4,'T4522',196,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (105,2,5,'IM3P10L',2778,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (106,1,9,'S3163031',249,8);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (106,2,8,'LA1425EC',72,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (106,3,5,'IM1P32V',1113,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (106,4,11,'L34211',96,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (106,5,9,'L85684',338,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (106,6,2,'L77712',1365,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (106,7,2,'LLST90',6484,2);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (107,1,3,'P434L',507,20);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (107,2,7,'L85509',168,3);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (107,3,12,'IM3P20V',1641,10);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (107,4,9,'P913',84,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (108,1,8,'LAF22C',675,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (108,2,2,'L77211',61,21);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (108,3,9,'L34043',228,24);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (108,4,7,'UP250P3',17613,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (108,6,3,'L83021',288,18);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (109,1,7,'IM3P32V',1966,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (109,2,9,'L85684',633,22);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (109,3,9,'L16045',264,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (110,2,2,'L86330',67,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (110,3,2,'S3144231',381,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (110,4,12,'TNF16',26,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (110,5,8,'TNF16',30,15);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (110,6,12,'L57368',455,9);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (111,2,2,'N8010BA',596,6);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (111,3,6,'L85318',117,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (112,1,12,'L86350',40,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (112,2,-3,'TE3102',3048,0);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (112,3,11,'TSP13.5',102,4);


insert into lineas_fac (codfac, linea, cant, codart, precio, dto) values (112,4,4,'VI535E',168,0);

commit;